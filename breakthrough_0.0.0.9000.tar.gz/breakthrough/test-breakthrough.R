library(testthat)

#loading installed package
#package for import .xls file
library(xlsx)
data <- read.xlsx("Radium.xlsx",sheetIndex=1)
  
#calculate average flow rate
flow.avg <- mean(data$Flow_Rate[1:length(data$Flow_Rate)-1])
  
#calculate the volume of water that flows through the column
volume <- data$Reaction_Time[1:length(data$Reaction_Time)-1]*flow.avg

#Define molar weigth of elements
Na_MW <- 22.99
Mg_MW <- 24.305
Ca_MW <- 40.078
Ba_MW <- 137.33
Sr_MW <- 87.62 
  
#calculate delta_conc (concentration change)
if(element=="Ra"){
  conc <- (data$Ra226*data$Dilution2)[1:length(data$Ra226)-1]  #actual effluent concentration of Ra
  influent <- (data$Ra226*data$Dilution2)[length(data$Ra226)]  #actual influent concentration of Ra
  } else if(element=="Na"){
    conc <- (data$Na23*data$Dilution1/Na_MW)[1:length(data$Na23)-1]  #actual effluent concentration of Na
    influent <- (data$Na23*data$Dilution1/Na_MW)[length(data$Na23)]  #actual influent concentration of Na
  } else if(element=="Mg"){
    conc <- (data$Mg24*data$Dilution1/Mg_MW)[1:length(data$Mg24)-1]  #actual effluent concentration of Mg
    influent <- (data$Mg24*data$Dilution1/Mg_MW)[length(data$Mg24)]  #actual influent concentration of Mg
  } else if(element=="Ca"){
    conc <- (data$Ca44*data$Dilution1/Ca_MW)[1:length(data$Ca44)-1]  #actual effluent concentration of Ca
    influent <- (data$Ca44*data$Dilution1/Ca_MW)[length(data$Ca44)]  #actual influent concentration of Ca
  } else if(element=="Ba"){
    conc <- (data$Ba137*data$Dilution1/Ba_MW)[1:length(data$Ba137)-1]  #actual effluent concentration of Ba
    influent <- (data$Ba137*data$Dilution1/Ba_MW)[length(data$Ba137)]  #actual influent concentration of Ba
  } else {
    conc <- (data$Sr88*data$Dilution1/Sr_MW)[1:length(data$Sr88)-1]  #actual effluent concentration of Sr
    influent <- (data$Sr88*data$Dilution1/Sr_MW)[length(data$Sr88)]  #actual influent concentration of Sr
  }
  
delta_conc <- influent - conc  #calculate concentration changes
  
#calculate delta_volume (volume change)
delta_volume <- NA  #pre-define delta_volume
for(i in 1:length(data$Ra226)-1)
{
  if(i==1){
  delta_volume[i] <- volume[i]
  } else  delta_volume[i] <- volume[i]-volume[i-1]
}
  
#calculate amount of ion exchange
amount <- sum(delta_conc*delta_volume/1000)  #ion-exchange amount
  
#calculate ion-exchange capacity
capacity <- amount/weight
#define the unit
if(element=="Ra"){
  unit <- "nCi/g"  
} else {unit <- "m moles/g"}
element.capacity <- paste("Ion-exchange capacity for",element,"is",capacity,unit)




#Test
t1 <- expect_equal(flow.avg,1.24)
t1


#Test
t2 <- expect_equal(capacity,0.154)
t2


#Test
element <- "Ra"
weight <- 9.6